import "./App.css";
import StockExchange from "./components/StockExchange";
function App() {
  return (
    <div className="App">
      <StockExchange></StockExchange>
      <footer>US Stock Exchange</footer>
    </div>
  )
}

export default App;
